# Car Rental Management System – Frontend Kubernetes Deployment

## 🚀 Project Overview
This repository contains Kubernetes manifests and Dockerfile required to deploy the Car Rental Management System (CRMS) Frontend into a Kubernetes cluster.

## 📌 Project Structure
/k8s  
   deployment.yaml  
   service.yaml  
Dockerfile  
README.md  

## 🛠 Steps to Deploy

### 1. Build Docker Image
docker build -t your-dockerhub-username/crms-frontend:latest .  
docker push your-dockerhub-username/crms-frontend:latest  

### 2. Apply Kubernetes Files
kubectl apply -f k8s/deployment.yaml  
kubectl apply -f k8s/service.yaml  

### 3. Access Frontend
minikube service crms-frontend-service  
